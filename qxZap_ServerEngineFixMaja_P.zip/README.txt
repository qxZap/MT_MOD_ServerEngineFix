Drag the .pak file inside the Paks folder 
Motor Town Behind The Wheel - Dedicated Server\MotorTown\Content\Paks
where you can find MotorTown-WindowsServer.pak

Then restart the server!